// Motiejus Kazabuckas, EDIf-24/2
// JavaScript formos apdorojimas - 11 laboratorinis darbas
// Atminties kortelių žaidimas - 12 laboratorinis darbas

document.addEventListener("DOMContentLoaded", () => {
  // ===================================
  // FORMOS APDOROJIMAS (11 LD)
  // ===================================

  // Gaunami formos elementai
  const form = document.getElementById("contactForm")
  const rating1Input = document.getElementById("rating1")
  const rating2Input = document.getElementById("rating2")
  const rating3Input = document.getElementById("rating3")
  const rating1Value = document.getElementById("rating1Value")
  const rating2Value = document.getElementById("rating2Value")
  const rating3Value = document.getElementById("rating3Value")

  // Atnaujinami slankiklių reikšmių tekstai
  rating1Input.addEventListener("input", function () {
    rating1Value.textContent = this.value
  })

  rating2Input.addEventListener("input", function () {
    rating2Value.textContent = this.value
  })

  rating3Input.addEventListener("input", function () {
    rating3Value.textContent = this.value
  })

  // Formos pateikimo apdorojimas
  form.addEventListener("submit", (e) => {
    e.preventDefault() // Sustabdomas numatytasis formos persikrovimas

    // Surenkamos visos įvesties vertės
    const formData = {
      vardas: document.getElementById("firstName").value,
      pavarde: document.getElementById("lastName").value,
      elpastas: document.getElementById("email").value,
      telefonas: document.getElementById("phone").value,
      adresas: document.getElementById("address").value,
      vertinimas1: Number.parseInt(rating1Input.value),
      vertinimas2: Number.parseInt(rating2Input.value),
      vertinimas3: Number.parseInt(rating3Input.value),
    }

    // Išvedamas objektas naršyklės konsolėje
    console.log("Formos duomenys:", formData)

    // Apskaičiuojamas įvertinimų vidurkis
    const average = ((formData.vertinimas1 + formData.vertinimas2 + formData.vertinimas3) / 3).toFixed(1)

    // Atvaizdavimas svetainėje
    const resultsDiv = document.getElementById("formResults")
    const resultsContent = document.getElementById("resultsContent")

    resultsContent.innerHTML = `
            <p><strong>Vardas:</strong> ${formData.vardas}</p>
            <p><strong>Pavardė:</strong> ${formData.pavarde}</p>
            <p><strong>El. paštas:</strong> ${formData.elpastas}</p>
            <p><strong>Tel. Numeris:</strong> ${formData.telefonas}</p>
            <p><strong>Adresas:</strong> ${formData.adresas}</p>
            <hr>
            <p><strong>Kokybės įvertinimas:</strong> ${formData.vertinimas1}</p>
            <p><strong>Aptarnavimo įvertinimas:</strong> ${formData.vertinimas2}</p>
            <p><strong>Bendrasis įvertinimas:</strong> ${formData.vertinimas3}</p>
            <hr>
            <p class="text-primary fs-5"><strong>${formData.vardas} ${formData.pavarde}: ${average}</strong></p>
        `

    resultsDiv.style.display = "block"

    // Rodomas sėkmės pranešimas
    showSuccessMessage()

    // Prasukamas puslapis į rezultatus
    resultsDiv.scrollIntoView({ behavior: "smooth", block: "nearest" })
  })

  // Funkcija sėkmės pranešimui
  function showSuccessMessage() {
    // Sukuriamas pranešimo elementas
    const message = document.createElement("div")
    message.className = "success-popup"
    message.innerHTML = `
            <div class="success-popup-content">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <h4>Duomenys pateikti sėkmingai!</h4>
                <p>Dėkojame už jūsų atsiliepimą</p>
            </div>
        `

    document.body.appendChild(message)

    // Animacija
    setTimeout(() => {
      message.classList.add("show")
    }, 10)

    // Pašalinamas po 3 sekundžių
    setTimeout(() => {
      message.classList.remove("show")
      setTimeout(() => {
        message.remove()
      }, 300)
    }, 3000)
  }

  // ===================================
  // ATMINTIES KORTELIŲ ŽAIDIMAS (12 LD)
  // ===================================

  // Kortelių duomenų rinkinys (8 unikalūs elementai)
  const cardIcons = [
    "fa-heart",
    "fa-star",
    "fa-moon",
    "fa-sun",
    "fa-cloud",
    "fa-bolt",
    "fa-tree",
    "fa-fire",
    "fa-mountain",
    "fa-fish",
    "fa-bug",
    "fa-leaf",
  ]

  // Žaidimo būsena
  const gameState = {
    difficulty: "easy",
    cards: [],
    flippedCards: [],
    matchedPairs: 0,
    moves: 0,
    totalPairs: 0,
    isGameStarted: false,
    isGameActive: false,
    timerInterval: null,
    startTime: null,
    elapsedTime: 0,
  }

  // DOM elementai
  const gameBoard = document.getElementById("gameBoard")
  const startButton = document.getElementById("startButton")
  const resetButton = document.getElementById("resetButton")
  const movesCount = document.getElementById("movesCount")
  const pairsCount = document.getElementById("pairsCount")
  const timerDisplay = document.getElementById("timerDisplay")
  const bestScore = document.getElementById("bestScore")
  const winMessage = document.getElementById("winMessage")
  const winStats = document.getElementById("winStats")
  const difficultyInputs = document.querySelectorAll('input[name="difficulty"]')

  // Sunkumo lygio pasikeitimas
  difficultyInputs.forEach((input) => {
    input.addEventListener("change", (e) => {
      if (!gameState.isGameStarted) {
        gameState.difficulty = e.target.value
        updateBestScore()
      } else {
        // Jei žaidimas pradėtas, grąžiname atgal
        document.getElementById(`difficulty${gameState.difficulty === "easy" ? "Easy" : "Hard"}`).checked = true
        alert("Prašome baigti esamą žaidimą arba paspausti 'Atnaujinti'")
      }
    })
  })

  // Start mygtukas
  startButton.addEventListener("click", () => {
    if (!gameState.isGameStarted) {
      startGame()
    }
  })

  // Reset mygtukas
  resetButton.addEventListener("click", () => {
    resetGame()
  })

  // Žaidimo pradžia
  function startGame() {
    resetGame()
    gameState.isGameStarted = true
    gameState.isGameActive = true
    startButton.disabled = true
    startButton.innerHTML = '<i class="fas fa-hourglass-half"></i> Žaidžiama...'

    // Uždraudžiame sudėtingumo keitimą
    difficultyInputs.forEach((input) => (input.disabled = true))

    // Paleidžiame laikmatį
    startTimer()

    // Įjungiame kortelių interaktyvumą
    enableCards()
  }

  // Žaidimo atstatymas
  function resetGame() {
    // Sustabdome laikmatį
    stopTimer()

    // Atstatome būseną
    gameState.flippedCards = []
    gameState.matchedPairs = 0
    gameState.moves = 0
    gameState.isGameStarted = false
    gameState.isGameActive = false
    gameState.elapsedTime = 0

    // Leidžiame sudėtingumo keitimą
    difficultyInputs.forEach((input) => (input.disabled = false))

    // Atstatome mygtukus
    startButton.disabled = false
    startButton.innerHTML = '<i class="fas fa-play"></i> Start'

    // Slepiame laimėjimo pranešimą
    winMessage.style.display = "none"

    // Generuojame naują lentą
    generateBoard()

    // Atnaujiname statistiką
    updateStats()
  }

  // Laikmatuvo funkcijos
  function startTimer() {
    gameState.startTime = Date.now() - gameState.elapsedTime
    gameState.timerInterval = setInterval(() => {
      gameState.elapsedTime = Date.now() - gameState.startTime
      updateTimerDisplay()
    }, 100)
  }

  function stopTimer() {
    if (gameState.timerInterval) {
      clearInterval(gameState.timerInterval)
      gameState.timerInterval = null
    }
  }

  function updateTimerDisplay() {
    const totalSeconds = Math.floor(gameState.elapsedTime / 1000)
    const minutes = Math.floor(totalSeconds / 60)
    const seconds = totalSeconds % 60
    timerDisplay.textContent = `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
  }

  // Lentos generavimas
  function generateBoard() {
    // Nustatome porų skaičių pagal sunkumą
    const pairsNeeded = gameState.difficulty === "easy" ? 6 : 12
    gameState.totalPairs = pairsNeeded

    // Paruošiame kortelių masyvą
    const selectedIcons = cardIcons.slice(0, pairsNeeded)
    const cardsArray = [...selectedIcons, ...selectedIcons]

    // Sumaišome korteles
    gameState.cards = shuffleArray(cardsArray)

    // Išvalome lentą
    gameBoard.innerHTML = ""
    gameBoard.className = `game-board ${gameState.difficulty}`

    // Sukuriame korteles
    gameState.cards.forEach((icon, index) => {
      const card = createCard(icon, index)
      gameBoard.appendChild(card)
    })

    // Atnaujinome statistiką
    updateStats()
  }

  // Kortelės sukūrimas
  function createCard(icon, index) {
    const cardElement = document.createElement("div")
    cardElement.className = "memory-card"
    cardElement.dataset.index = index
    cardElement.dataset.icon = icon

    cardElement.innerHTML = `
            <div class="card-face card-front">
                <i class="fas fa-question"></i>
            </div>
            <div class="card-face card-back">
                <i class="fas ${icon}"></i>
            </div>
        `

    return cardElement
  }

  // Kortelių interaktyvumo įjungimas
  function enableCards() {
    const cards = document.querySelectorAll(".memory-card")
    cards.forEach((card) => {
      card.addEventListener("click", handleCardClick)
    })
  }

  // Kortelės paspaudimo apdorojimas
  function handleCardClick(e) {
    if (!gameState.isGameActive) return

    const card = e.currentTarget

    // Neleisti paspausti jau atverstos arba suderintos kortelės
    if (card.classList.contains("flipped") || card.classList.contains("matched")) {
      return
    }

    // Neleisti atversti daugiau nei 2 korteles
    if (gameState.flippedCards.length >= 2) {
      return
    }

    // Apverčiame kortelę
    card.classList.add("flipped")
    gameState.flippedCards.push(card)

    // Jei atverstos 2 kortelės, tikriname
    if (gameState.flippedCards.length === 2) {
      gameState.moves++
      updateStats()
      checkMatch()
    }
  }

  // Kortelių sutapimo tikrinimas
  function checkMatch() {
    const [card1, card2] = gameState.flippedCards

    const icon1 = card1.dataset.icon
    const icon2 = card2.dataset.icon

    if (icon1 === icon2) {
      // Sutampa!
      card1.classList.add("matched")
      card2.classList.add("matched")
      gameState.matchedPairs++
      gameState.flippedCards = []

      updateStats()

      // Tikriname ar laimėta
      if (gameState.matchedPairs === gameState.totalPairs) {
        winGame()
      }
    } else {
      // Nesutampa - apverčiame atgal po 1 sekundės
      gameState.isGameActive = false
      setTimeout(() => {
        card1.classList.remove("flipped")
        card2.classList.remove("flipped")
        gameState.flippedCards = []
        gameState.isGameActive = true
      }, 1000)
    }
  }

  // Statistikos atnaujinimas
  function updateStats() {
    movesCount.textContent = gameState.moves
    pairsCount.textContent = `${gameState.matchedPairs} / ${gameState.totalPairs}`
  }

  // Laimėjimo apdorojimas
  function winGame() {
    gameState.isGameActive = false
    stopTimer()

    // Rodom laimėjimo pranešimą
    const timeInSeconds = Math.floor(gameState.elapsedTime / 1000)
    winStats.textContent = `Baigėte per ${gameState.moves} ėjimus ir ${timeInSeconds} sekundžių!`
    winMessage.style.display = "block"

    // Išsaugome geriausią rezultatą
    saveBestScore()

    // Leidžiame pradėti naują žaidimą
    startButton.disabled = false
    startButton.innerHTML = '<i class="fas fa-play"></i> Start'
    gameState.isGameStarted = false

    // Leidžiame keisti sudėtingumą
    difficultyInputs.forEach((input) => (input.disabled = false))

    // Prasukame į pranešimą
    winMessage.scrollIntoView({ behavior: "smooth", block: "center" })
  }

  // localStorage funkcijos
  function saveBestScore() {
    const key = `memoryGame_best_${gameState.difficulty}`
    const currentBest = localStorage.getItem(key)

    if (!currentBest || gameState.moves < Number.parseInt(currentBest)) {
      localStorage.setItem(key, gameState.moves)
      updateBestScore()
    }
  }

  function updateBestScore() {
    const key = `memoryGame_best_${gameState.difficulty}`
    const best = localStorage.getItem(key)

    if (best) {
      bestScore.textContent = `${best} ėjimai`
    } else {
      bestScore.textContent = "-"
    }
  }

  // Pagalbinė funkcija masyvui sumaišyti (Fisher-Yates shuffle)
  function shuffleArray(array) {
    const newArray = [...array]
    for (let i = newArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[newArray[i], newArray[j]] = [newArray[j], newArray[i]]
    }
    return newArray
  }

  // Inicializuojame žaidimą
  generateBoard()
  updateBestScore()
})
