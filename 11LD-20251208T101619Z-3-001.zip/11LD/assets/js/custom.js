// Motiejus Kazabuckas, EDIf-24/2
// JavaScript formos apdorojimas - 11 laboratorinis darbas

document.addEventListener("DOMContentLoaded", () => {
  // Gaunami formos elementai
  const form = document.getElementById("contactForm")
  const rating1Input = document.getElementById("rating1")
  const rating2Input = document.getElementById("rating2")
  const rating3Input = document.getElementById("rating3")
  const rating1Value = document.getElementById("rating1Value")
  const rating2Value = document.getElementById("rating2Value")
  const rating3Value = document.getElementById("rating3Value")

  // Atnaujinami slankiklių reikšmių tekstai
  rating1Input.addEventListener("input", function () {
    rating1Value.textContent = this.value
  })

  rating2Input.addEventListener("input", function () {
    rating2Value.textContent = this.value
  })

  rating3Input.addEventListener("input", function () {
    rating3Value.textContent = this.value
  })

  // Formos pateikimo apdorojimas
  form.addEventListener("submit", (e) => {
    e.preventDefault() // Sustabdomas numatytasis formos persikrovimas

    // Surenkamos visos įvesties vertės
    const formData = {
      vardas: document.getElementById("firstName").value,
      pavarde: document.getElementById("lastName").value,
      elpastas: document.getElementById("email").value,
      telefonas: document.getElementById("phone").value,
      adresas: document.getElementById("address").value,
      vertinimas1: Number.parseInt(rating1Input.value),
      vertinimas2: Number.parseInt(rating2Input.value),
      vertinimas3: Number.parseInt(rating3Input.value),
    }

    // Išvedamas objektas naršyklės konsolėje
    console.log("Formos duomenys:", formData)

    // Apskaičiuojamas įvertinimų vidurkis
    const average = ((formData.vertinimas1 + formData.vertinimas2 + formData.vertinimas3) / 3).toFixed(1)

    // Atvaizdavimas svetainėje
    const resultsDiv = document.getElementById("formResults")
    const resultsContent = document.getElementById("resultsContent")

    resultsContent.innerHTML = `
            <p><strong>Vardas:</strong> ${formData.vardas}</p>
            <p><strong>Pavardė:</strong> ${formData.pavarde}</p>
            <p><strong>El. paštas:</strong> ${formData.elpastas}</p>
            <p><strong>Tel. Numeris:</strong> ${formData.telefonas}</p>
            <p><strong>Adresas:</strong> ${formData.adresas}</p>
            <hr>
            <p><strong>Kokybės įvertinimas:</strong> ${formData.vertinimas1}</p>
            <p><strong>Aptarnavimo įvertinimas:</strong> ${formData.vertinimas2}</p>
            <p><strong>Bendrasis įvertinimas:</strong> ${formData.vertinimas3}</p>
            <hr>
            <p class="text-primary fs-5"><strong>${formData.vardas} ${formData.pavarde}: ${average}</strong></p>
        `

    resultsDiv.style.display = "block"

    // Rodomas sėkmės pranešimas
    showSuccessMessage()

    // Prasukamas puslapis į rezultatus
    resultsDiv.scrollIntoView({ behavior: "smooth", block: "nearest" })
  })

  // Funkcija sėkmės pranešimui
  function showSuccessMessage() {
    // Sukuriamas pranešimo elementas
    const message = document.createElement("div")
    message.className = "success-popup"
    message.innerHTML = `
            <div class="success-popup-content">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <h4>Duomenys pateikti sėkmingai!</h4>
                <p>Dėkojame už jūsų atsiliepimą</p>
            </div>
        `

    document.body.appendChild(message)

    // Animacija
    setTimeout(() => {
      message.classList.add("show")
    }, 10)

    // Pašalinamas po 3 sekundžių
    setTimeout(() => {
      message.classList.remove("show")
      setTimeout(() => {
        message.remove()
      }, 300)
    }, 3000)
  }
})
